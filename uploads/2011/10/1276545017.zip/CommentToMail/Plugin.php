<?php
/**
 * 评论回复邮件提醒插件
 *
 * @package CommentToMail
 * @author df
 * @version 1.2.1
 * @link http://df-blog.cn
 */
class CommentToMail_Plugin implements Typecho_Plugin_Interface {
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate() {
        Typecho_Plugin::factory('Widget_Feedback')-> finishComment = array('CommentToMail_Plugin', 'toMail');
        return _t('请对插件进行正确设置，以使插件顺利工作！') . $error;
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate() {

    }

    /**
     * 获取插件配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form) {
        $cfg_mode= new Typecho_Widget_Helper_Form_Element_Radio('cfg_mode',
                array( 'smtp' => 'smtp',
                    'mail' => 'mail()',
                        'sendmail' => 'sendmail()'),
                'smtp', '发信方式');
        $form->addInput($cfg_mode);

        $cfg_host = new Typecho_Widget_Helper_Form_Element_Text('cfg_host', NULL, 'smtp.',
                _t('SMTP地址'), _t('请填写 SMTP 服务器地址'));
        $form->addInput($cfg_host->addRule('required', _t('必须填写一个SMTP服务器地址')));

        $cfg_port = new Typecho_Widget_Helper_Form_Element_Text('cfg_port', NULL, '25',
                _t('SMTP端口'), _t('SMTP服务端口,一般为25。'));
        $cfg_port->input->setAttribute('class', 'mini');
        $form->addInput($cfg_port->addRule('required', _t('必须填写SMTP服务端口'))
                ->addRule('isInteger', _t('端口号必须是纯数字')));

        $cfg_user = new Typecho_Widget_Helper_Form_Element_Text('cfg_user', NULL, NULL,
                _t('SMTP用户'),_t('SMTP服务验证用户名,一般为邮箱名如：youname@domain.com'));
        $form->addInput($cfg_user->addRule('required', _t('SMTP服务验证用户名')));

        $cfg_pass = new Typecho_Widget_Helper_Form_Element_Password('cfg_pass', NULL, NULL,
                _t('SMTP密码'));
        $form->addInput($cfg_pass->addRule('required', _t('SMTP服务验证密码')));

        $cfg_validate=new Typecho_Widget_Helper_Form_Element_Checkbox('cfg_validate',
                array('validate'=>'服务器需要验证',
                    'ssl'=>'ssl加密'),
                array('validate'),'SMTP验证');
        $form->addInput($cfg_validate);

        $cfg_mail = new Typecho_Widget_Helper_Form_Element_Text('cfg_mail', NULL, NULL,
                _t('接收邮箱'),_t('接收邮件用的信箱,如为空则使用博客创建者个人设置中的邮箱！'));
        $form->addInput($cfg_mail->addRule('email', _t('请填写正确的邮箱！')));

        $cfg_send = new Typecho_Widget_Helper_Form_Element_Checkbox('cfg_send',
                array('approved' => '提醒已通过评论',
                        'waiting' => '提醒待审核评论',
                        'spam' => '提醒垃圾评论'),
                array('approved', 'waiting'), '提醒设置');
        $form->addInput($cfg_send);

        $cfg_other = new Typecho_Widget_Helper_Form_Element_Checkbox('cfg_other',
                array('to_me' => '有评论及回复时，发邮件通知博主。',
                    'to_other' => '评论被回复时，发邮件通知评论者。',
                    'to_log' => '记录邮件发送日志。'),
                array('to_me','to_other'), '其他设置',_t('如果选上"记录邮件发送日志"选项，则会在./usr/mail_log.txt 文件中记录发送信息。<br />建议仅在收不到邮件时开启该功能以便查看日志。'));
        $form->addInput($cfg_other->multiMode());

        $cfg_title = new Typecho_Widget_Helper_Form_Element_Text('cfg_title',null,"[{site}]:《{title}》一文有新的评论",
                _t('邮件标题'));
        $form->addInput($cfg_title);

        $cfg_format = new Typecho_Widget_Helper_Form_Element_Textarea('cfg_format', NULL, NULL,
			_t('邮件正文'), _t('站名{site} 文章名{title} 作者{author} IP{ip} 评论者邮箱{mail} 评论链接{permalink} <br />管理评论{manage} 评论内容{text} 时间{time} 评论状态{status}'));
        $form->addInput($cfg_format);

        $cfg_title1 = new Typecho_Widget_Helper_Form_Element_Text('cfg_title1',null,"[{site}]:您在《{title}》一文的评论有了回复",
                _t('回复评论者邮件标题'));
        $form->addInput($cfg_title1);

        $cfg_format1 = new Typecho_Widget_Helper_Form_Element_Textarea('cfg_format1', NULL, "",
			_t('回复邮件正文'), _t('站名{site} 文章名{title} 作者{author} IP{ip} 评论者邮箱{mail} 评论链接{permalink} <br />评论内容{text} 原评论作者{author_p} 原评论内容{text_p}'));
        $form->addInput($cfg_format1);
    }

    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form) {

    }

    /**
     *组合邮件内容
     * @access public
     * @param $post 调用参数
     * @return void
     */
    public static function toMail($post) {
        date_default_timezone_set('Asia/Chongqing');
        $db = Typecho_Db::get();
        $options = Typecho_Widget::widget('Widget_Options');
        $site = $options->title;
        $settings = Helper::options()->plugin('CommentToMail');
        $smtp=array();
        $smtp['mode']=$settings->cfg_mode;
        $smtp['site']=$site;

        /**获取SMTP设置*/
        $smtp['user'] = $settings->cfg_user;
        $smtp['pass'] = $settings->cfg_pass;
        $smtp['host'] = $settings->cfg_host;
        $smtp['port'] = $settings->cfg_port;

        //获取验证信息
        if(in_array('validate',$settings->cfg_validate)) $smtp['validate']=true;
        if(in_array('ssl',$settings->cfg_validate)) $smtp['ssl']=true;

        /**发信到博主信箱  */
        if(in_array($post->status,$settings->cfg_send) && $post->ownerId!=$post->authorId && in_array('to_me',$settings->cfg_other)) {
            /**格式化评论发布时间*/
            $d=getdate($post->created);
            $times = $d['year']."年".$d['mon']."月".$d['mday']."日".$d['hours'].":".$d['minutes'].":".$d['seconds'];

            /**评论状态*/
            switch($post->status) {
                case "approved":
                    $sta='<font color="#008040">已通过</font>';
                    break;
                case "waiting":
                    $sta='<font color="#FF8000">待审核</font>';
                    break;
                case "spam":
                    $sta='<font color="#FF0000">垃圾</font>';
                    break;
            }
            /**管理评论链接*/
            $manage= $options->siteUrl."admin/manage-comments.php";
            /**获取邮件正文格式*/
            if(!$settings->cfg_format){
                $format="{site}上的《{title}》一文有新的评论，该评论状态：{status}<br />";
                $format.="作者：{author}<br />";
                $format.="邮箱：<a href='mailto:{mail}'>{mail}</a><br />";
                $format.="时间：{time}<br />";
                $format.="链接：<a href='{permalink}' target='_blank'>{permalink}</a><br /><br />";
                $format.="评论：  [<a href='{manage}' target='_blank'> 管理评论 </a>] <br />";
                $format.="-------------------------------------------------------------------------------- <br />";
                $format.="{text}<br />";
            }else{
                $format=$settings->cfg_format;
            }
            /***/
            $smtp['AltBody']="作者：".$post->author."\r\n链接：".$post->permalink."\r\n评论：\r\n".$post->text;
            /**处理邮件正文*/
            $search=array('{site}','{title}','{author}','{ip}','{mail}','{permalink}','{manage}','{text}','{time}','{status}');
            $replace=array($site,$post->title,$post->author,$post->ip,$post->mail,$post->permalink,$manage,$post->text,$times,$sta);
            $smtp['body']=str_replace($search, $replace, $format);

            /**邮件标题*/
            //$smtp['subject']="[".$site."]:《".$post->title."》一文有新的评论";
            if($settings->cfg_title){
                $title=$settings->cfg_title;
            }else{
                $title="[{site}]:《{title}》一文有新的评论";
            }
            $smtp['subject']=str_replace($search, $replace, $title);


            /**获取接收邮箱*/
            if($settings->cfg_mail!="") {
                $email_to=$settings->cfg_mail;
            }else {
                $select=Typecho_Widget::widget('Widget_Abstract_Users')->select()->where('uid',1);
                $result = $db->query($select);
                $row = $db->fetchRow($result);
                $email_to=$row['mail'];
            }

            $smtp['to']=$email_to;
            $smtp['from']=$email_to;
            $smtp['to_name']='';

            /**发信*/
            $ck=self::SendMail($smtp);
        }

        /**评论被回复时，发信通知评论者*/
        if(0!=$post->parent && in_array($post->status,$settings->cfg_send) && in_array('to_other',$settings->cfg_other)) {

            $select=$db->select('author','mail','text')
                    ->from('table.comments')
                    ->where('coid = ?', $post->parent);
            $result = $db->query($select);
            $row = $db->fetchRow($result);

            $smtp['to']=$row['mail'];
            $smtp['to_name']=$row['author'];

            if($row['mail']!=$post->mail) {

                /**取得标题格式*/
                if($settings->cfg_title1){
                    $title1=$settings->cfg_title1;
                }else{
                    $title1="[".$site."]:您在《".$post->title."》的评论有了回复";
                }

                /**取得邮件主体格式*/
                if(!$settings->cfg_format1){
                    $format1 = "{author_p}您在{site}上的《{title}》一文发表的评论有了回复。<br />";
                    $format1.= "作者：{author}<br />";
                    $format1.= "链接：<a href='{permalink}' target='_blank'>{permalink}</a><br />";
                    $format1.= "回复：<br />";
                    $format1.="-------------------------------------------------------------------------------- <br />";
                    $format1.= "{text}<br />";
                    $format1.="-------------------------------------------------------------------------------- <br /><br />";
                    $format1.="您的评论原文:<br />";
                    $format1.="-------------------------------------------------------------------------------- <br />";
                    $format1.="{text_p}<br />";
                   
                }else{
                    $format1=$settings->cfg_format1;
                }

                $search1=array('{site}','{title}','{author_p}','{author}','{ip}','{mail}','{permalink}','{text}','{text_p}');
                $replace1=array($site,$post->title,$row['author'],$post->author,$post->ip,$post->mail,$post->permalink,$post->text,$row['text']);
                $smtp['body']=str_replace($search1, $replace1, $format1);
                $smtp['subject']=str_replace($search1, $replace1, $title1);
                $smtp['AltBody']="作者：".$post->author."\r\n链接：".$post->permalink."\r\n评论：\r\n".$post->text;

                $ck1=self::SendMail($smtp);
            }
        }
        //记录日志到文件
        if(in_array('to_log', $settings->cfg_other)) {
            $file="./usr/mail_log.txt";
            $fp1=@fopen($file,'a+');
            fwrite($fp1,date("Y-m-d H:i:s")." 开始发送！\r\n");
            fwrite($fp1,"向博主".$email_to."发信：\r\n".$ck.($ck==""?"发送成功！\r\n":"发送失败！\r\n"));
            fwrite($fp1,"向评论者".$smtp['to']."发信：\r\n".$ck1.($ck1==""?"发送成功！\r\n":"发送失败！\r\n"));
            fclose($fp1);
        }
    }

     /**
     * 发送邮件
     *
     * @access public
     * @param array $smtp 邮件信息
     * @return void
     */
    public static function SendMail($smtp) {
        require_once('saemail.class.php');
		$mail = new SaeMail();
		//$mail->setAttach( array( 'my_photo' => '照片的二进制数据' ) );
		//$ret = $mail->quickSend( $smtp['to'], $smtp['subject'] , $smtp['body'] , $smtp['user'] ,$smtp['pass'],"smtp.qq.com",25 );
		$mail->setOpt(array(
			'from' => $smtp['user'],
			'to' => $smtp['to'],
			'smtp_host' => 'smtp.qq.com',
			'smtp_port' => 25,
			'smtp_username' => $smtp['user'],
			'smtp_password' => $smtp['pass'],
			'subject' => $smtp['subject'],
			'content' => $smtp['body'],
			'content_type' => "HTML",
			'tls' => 'true'
		));
		$mail->send();
    }
}
