//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by emWin.rc
//
#define IDM_FILE                        100
#define IDM_EXIT                        101
#define IDM_VIEW                        102
#define IDM_HELP                        103
#define IDS_APP_TITLE                   103
#define IDS_HELLO                       106
#define IDM_LOG                         107
#define IDB_DEVICE2                     133
#define IDB_DEVICE                      134
#define IDC_POPEMWIN                    135
#define IDD_LOG                         136
#define IDD_EMWIN_DIALOG                200
#define IDD_ABOUTBOX                    201
#define IDI_EMWIN                       300
#define IDI_SMALL                       301
#define IDI_ICON1                       302
#define IDC_STATIC                      400
#define IDC_EMWIN                       401
#define IDC_MYICON                      402
#define IDR_MAINFRAME                   500
#define IDB_BITMAP1                     501
#define IDB_LOGO                        501
#define ID_ABOUT_COPYRIGHT              1000
#define IDC_EDITLOG                     1000
#define ID_ABOUT_VERSION                1001
#define IDM_ABOUT                       1002
#define ID_ABOUT_APPC                   1002
#define IDM_COPYCLIP                    32770
#define IDM_NEWLCD                      32771
#define IDM_NEWCOLORS                   32772
#define ID_LOG                          32773
#define IDM_PAUSEAPP                    32775
#define IDM_RESUMEAPP                   32776
#define IDM_ALWAYSTOP                   32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
